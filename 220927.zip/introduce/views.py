from django.shortcuts import render
from .models import AccessLog


# Create your views here.
def introduce(request):
    # case 1
    # accesslog = AccessLog()
    # accesslog.location = "introduce"
    # accesslog.save()

    # case 2
    AccessLog.objects.create(
        location="introduce"
    )

    return render(request, 'introduce.html')